"""
Parser module for beancount input files.
"""

__copyright__ = "Copyright (C) 2013-2017, 2024-2025  Martin Blais"
__license__ = "GNU GPLv2"
