"""
Parser module for beancount input files.
"""

__copyright__ = "Copyright (C) 2013-2017  Martin Blais"
__license__ = "GNU GPLv2"
