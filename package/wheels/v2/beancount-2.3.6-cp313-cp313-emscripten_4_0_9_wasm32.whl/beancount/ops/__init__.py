"""Operations on the entries defined in the core modules.

This package contains various functions which operate on lists of entries.
"""

__copyright__ = "Copyright (C) 2013-2017  Martin Blais"
__license__ = "GNU GPLv2"
